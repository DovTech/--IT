﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace Олимпиада
{
    class MostPopWords
    {
        string word;
        int count;

        public string _word
        {
            get { return word; }
            set
            {
                if (value != null)
                    word = value;
            }
        }
        public int _count
        {
            get { return count; }
            set
            {
                if (value > -1)
                    count = value;
            }
        }

        public MostPopWords(string word)
        {
            this.word = word;
            this.count = 1;
        }

        public MostPopWords(string word, int count)
        {
            this.word = word;
            this.count = count;
        }

        public static List<MostPopWords> PageProcessing(string path)
        {
            FileStream fin;
            string[] splitText = new string[0];
            List<MostPopWords> result = new List<MostPopWords>();
            try
            {
                fin = new FileStream(path, FileMode.Open, FileAccess.Read);
            }
            catch (FileNotFoundException)
            {
                return null;
            }
            catch (IndexOutOfRangeException)
            {
                return null;
            }
            catch (ArgumentException)
            {
                return null;
            }
            StreamReader fin_strm = new StreamReader(fin);
            string text = fin_strm.ReadToEnd();
            text = Regex.Replace(text, @"<[^>]+>|&nbsp;", "");
            text = Regex.Replace(text, "[-.?!)(,:]", "");
            text = Regex.Replace(text, @"\s{2,}", " ");
            splitText = text.Split();
            Array.Sort(splitText);

            result = PopularWords(splitText);

            return result;
        }

        public static List<MostPopWords> PopularWords(string[] splitText)
        {
            List<MostPopWords> topWords = new List<MostPopWords>();
            string cloneWord = "";
            int cloneCount = 1;
            for (int i = 1; i < splitText.Length; i++)
            {
                if (cloneWord != splitText[i])
                {
                    cloneWord = splitText[i];
                    MostPopWords ob = new MostPopWords(cloneWord, cloneCount);
                    ob.count = cloneCount;
                    topWords.Add(ob);
                    cloneCount = 1;
                }
                else
                    cloneCount++;
            }
            topWords.Sort((a, b) => b.count.CompareTo(a.count));

            return topWords;
        }
    }
}
