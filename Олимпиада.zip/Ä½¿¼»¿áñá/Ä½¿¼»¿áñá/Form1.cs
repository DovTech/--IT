﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Олимпиада
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<MostPopWords> result = new List<MostPopWords>();
            while (true)
            {
                string s = richTextBox1.Text;
                result = MostPopWords.PageProcessing(s);
                if (result == null)
                    richTextBox1.Text = "Неверно указан путь";
                else break;
            }
            dataGridView1.DataSource = result;
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
